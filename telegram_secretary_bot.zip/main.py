import logging
import os
import datetime
from telegram import Update, ReplyKeyboardMarkup, KeyboardButton
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, ContextTypes, filters
import gspread
import smtplib
from email.message import EmailMessage

# Настройки
BOT_TOKEN = "7688965064:AAEitdF3pao8cZQs5guQJuJE5ZpyyH8A7zU"
EMAIL_RECEIVER = "eddi38rus@gmail.com"
WORK_START = 8
WORK_END = 17
GOOGLE_SHEET_NAME = "Секретарь"
GOOGLE_CREDENTIALS_FILE = "google-credentials.json"

# Включаем логирование
logging.basicConfig(level=logging.INFO)

# Клавиатура
keyboard = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton("Оставить заявку")],
        [KeyboardButton("Частые вопросы")],
        [KeyboardButton("График работы")],
    ],
    resize_keyboard=True
)

# Частые вопросы
FAQ = {
    "Когда будут дворники?": "Дворники выходят ежедневно с 7:00.",
    "Когда будет уборка подъезда?": "Уборка подъездов проводится по графику — 2 раза в неделю.",
    "Когда отремонтируют подъезд?": "Ремонт запланирован в течение ближайших месяцев.",
    "Когда будет покос травы?": "Покос травы проводится с мая по сентябрь по мере роста.",
    "Когда спилят деревья?": "Спил деревьев производится по заявкам и при аварийной необходимости."
}

# Отправка email
def send_email(subject, body):
    msg = EmailMessage()
    msg.set_content(body)
    msg["Subject"] = subject
    msg["From"] = "bot@example.com"
    msg["To"] = EMAIL_RECEIVER

    try:
        with smtplib.SMTP("smtp.gmail.com", 587) as smtp:
            smtp.starttls()
            smtp.login("your_email@gmail.com", "your_app_password")
            smtp.send_message(msg)
    except Exception as e:
        logging.error(f"Email error: {e}")

# Сохранение в таблицу
def save_to_sheet(name, text):
    try:
        gc = gspread.service_account(filename=GOOGLE_CREDENTIALS_FILE)
        sh = gc.open_by_url("https://docs.google.com/spreadsheets/d/1cSUbD5Sl8rJMxR2h3W9jsLFJ21sIa6ajndv5PxsucPU")
        worksheet = sh.sheet1
        worksheet.append_row([str(datetime.datetime.now()), name, text])
    except Exception as e:
        logging.error(f"Google Sheets error: {e}")

# Обработчики
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Здравствуйте! Я ваш секретарь. Выберите действие:",
        reply_markup=keyboard
    )

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text
    user = update.message.from_user
    username = user.username or user.first_name

    # Расписание
    now = datetime.datetime.now()
    if now.weekday() < 5 and (now.hour < WORK_START or now.hour >= WORK_END):
        await update.message.reply_text("Мы работаем с 8:00 до 17:00 по будням. Пожалуйста, напишите в рабочее время.")
        return

    # Частые вопросы
    if text in FAQ:
        await update.message.reply_text(FAQ[text])
        return

    if text == "Частые вопросы":
        await update.message.reply_text("Напишите один из вопросов:
" + "
".join(FAQ.keys()))
    elif text == "График работы":
        await update.message.reply_text("Мы работаем с 8:00 до 17:00 по будням.")
    elif text == "Оставить заявку":
        await update.message.reply_text("Пожалуйста, опишите вашу заявку одним сообщением.")
    else:
        # Сохраняем сообщение
        save_to_sheet(username, text)
        send_email("Новая заявка", f"От {username}:
{text}")
        await update.message.reply_text("Спасибо! Ваша заявка принята и передана на обработку.")

# Главный запуск
def main():
    app = ApplicationBuilder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    app.run_polling()

if __name__ == "__main__":
    main()
